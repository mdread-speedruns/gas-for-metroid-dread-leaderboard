// https://accounts.google.com/o/oauth2/auth?client_id=687320560874-5ivms6pn7fpmfff544qo8r1cdrklsrnk.apps.googleusercontent.com&redirect_uri=http://localhost&scope=https://www.googleapis.com/auth/spreadsheets&response_type=code&approval_prompt=force&access_type=offline
// http://localhost/?code=4/0AdQt8qj-GL0Qtyi7EG0BC5ZpL8xtVEDK1nZzHWFIOPU5mm3KnW0fQonliJ29cRINy6cHJw&scope=https://www.googleapis.com/auth/spreadsheets
// # URL = "https://script.googleapis.com/v1/scripts/AKfycbyqx02VzLElvtJCtKALN-IrO9DXhqgo1mvX-1bMhQUI6CPXb3LTaic9bS5NR22uhcnv:run"
// # CLIENT_ID = "687320560874-5ivms6pn7fpmfff544qo8r1cdrklsrnk.apps.googleusercontent.com"
// # CLIENT_SECRET = "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"
// # API_KEY = "AIzaSyAu6luYol8foTRgusvw9IDjWK7W96UEzV0"
// # TOKEN = "4/0AdQt8qj-GL0Qtyi7EG0BC5ZpL8xtVEDK1nZzHWFIOPU5mm3KnW0fQonliJ29cRINy6cHJw"

/**
 * {
  "access_token": "ya29.a0AVA9y1sG0vSsbsL-3sON0GHiD8MjTx72_Dhs7JpbopdnpZStXPXo1mzSsM6s_rpc7jakPx-WiQIc341I6NK0dGahkIl29t6wkgM8aQWaXasjMtGipb11xYQpISR7r-1w9LWkIseY1RcmkV_077gvjoG-XdkT",
  "expires_in": 3599,
  "refresh_token": "1//0eQ1JJQn5b6JTCgYIARAAGA4SNwF-L9Irc4PuC05OgUF8f7DyPqvNOtzbVOvIWQ4B0J14hmnqgA4zTmYrWlj6gO0azh5Htjb38G4",
  "scope": "https://www.googleapis.com/auth/spreadsheets",
  "token_type": "Bearer"
}
 * 
 */

function apiTest(): string {
    return "success";
}